//Initialize function
var init = function () {
    // TODO:: Do your initialization job
    console.log("init() called");
};
$(document).ready(init);
